import DashboardLayout from "../../layouts/DashboardLayout";

function DinasDashboard() {
  return (
    <DashboardLayout>

      <section className="space-y-3">

        <p className="text-base font-medium text-slate-400">
          Dinas Pendidikan
        </p>

        <h1 className="text-5xl font-bold tracking-tight text-slate-800">
          Dinas Dashboard
        </h1>

      </section>

    </DashboardLayout>
  );
}

export default DinasDashboard;