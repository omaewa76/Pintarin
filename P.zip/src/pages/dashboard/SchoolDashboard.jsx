function DinasDashboard() {
  return <h1>Dinas Dashboard</h1>;
}

export default DinasDashboard;