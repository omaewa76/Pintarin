function CSRDashboard() {
  return <h1>CSR Dashboard</h1>;
}

export default CSRDashboard;