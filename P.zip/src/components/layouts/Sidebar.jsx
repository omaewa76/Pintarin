function Sidebar() {
  return (
    <div>
      <h1 className="text-2xl font-bold">
        PINTARIN
      </h1>

      <ul className="mt-10 space-y-4">
        <li>Dashboard</li>
        <li>Risk Analysis</li>
        <li>Recommendations</li>
      </ul>
    </div>
  );
}

export default Sidebar;