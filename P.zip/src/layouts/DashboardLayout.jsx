import Navbar from "../components/layouts/Navbar";

function DashboardLayout({ children }) {
  return (
    <div className="flex min-h-screen bg-slate-100">

      {/* Sidebar */}
      <aside className="w-72 bg-blue-950 px-7 py-8 text-white">

        <h1 className="text-3xl font-bold tracking-tight">
          PINTARIN
        </h1>

      </aside>

      {/* Main Area */}
      <div className="flex-1 overflow-hidden">

        {/* Content Container */}
        <div className="px-8 py-7">

          {/* Navbar */}
          <Navbar />

          {/* Page Content */}
          <main className="mt-10">
            {children}
          </main>

        </div>

      </div>

    </div>
  );
}

export default DashboardLayout;